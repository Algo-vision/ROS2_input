from distutils.core import setup
setup(name='import_parents',
      version='1.0',
      py_modules=['import_parents'],
      author='Mark Levin',
      author_email='levmarki@gmail.com',
      url='facebook.com',
      )
